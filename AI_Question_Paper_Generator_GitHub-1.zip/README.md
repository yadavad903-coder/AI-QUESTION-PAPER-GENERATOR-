# AI Question Paper Generator

A beginner-friendly B.Tech CSE/AI-ML project that generates structured question papers for multiple subjects.

## Subjects
- Mathematics
- Physics
- Chemistry
- C++ Programming
- Computer Fundamentals
- English

## Features
- Subject selection
- Easy / Medium / Hard / Mixed difficulty
- Topic filter
- Custom number of questions
- Exam duration
- Smart randomized question selection
- Answer hints for demonstration
- Print / Save as PDF
- Responsive design
- No API key required for the demo

## Run locally
Open `index.html` in any modern browser.

## Upload to GitHub Pages
1. Create a new GitHub repository, for example `ai-question-paper-generator`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select `main` branch and `/ (root)`.
6. Save.
7. GitHub will provide the public Pages URL.

## How to explain the AI part
This prototype uses intelligent/randomized selection from a structured question bank based on subject, topic and difficulty. For a stronger AI/ML version, a backend can later connect an LLM/API to generate new questions dynamically from a syllabus or uploaded notes.

## Future enhancements
- PDF syllabus upload
- AI-generated questions from syllabus
- MCQ / short / long-answer sections
- Bloom's taxonomy based difficulty
- Automatic marks distribution
- Question-paper templates
- Database for question history
- Student login and saved papers
